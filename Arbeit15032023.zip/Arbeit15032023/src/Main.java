import java.util.Locale;

public class Main {
    public static void main(String[] args) {

        String stringText = "I stuby Basik Java!";
        System.out.println(stringText.charAt(18));

        System.out.println(stringText.contains("Java"));

        System.out.println(stringText.replace('a' , 'o'));

        System.out.println(stringText.toUpperCase());
        System.out.println(stringText.toLowerCase());

        System.out.println(stringText.substring(14));


        byte argByte = 125;
        int argInt = 23081976;
        double argDouble = 3.14;
        float argFloat = 123.321F;

        byte argByte1 = (byte)  argInt;
        int argInt1 = argByte +(int) argDouble;
        double argDouble1 = argFloat;
        float argFloat1 = (float) argDouble1;

        System.out.println(argByte1);
        System.out.println(argInt1);
        System.out.println(argDouble1);
        System.out.println(argFloat1);


        


    }
}